<div class="sidebar">
    <div class="cat-header">
    <div class="cat-head"><a>ताजा खबर  </a></div>
    </div>
        <?php def_bx(-100,10,0,12);?>
</div>