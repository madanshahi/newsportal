 <?php pradesh1_block(-100,1,0,60);?>
<div class="col colspan4">
<div class="left_add">
<div class="okam-ad-position-wrap home-after-desh-1news okam-device-mobile" data-alias="home-after-desh-1news" data-device-type="mobile">
</div>
</div>
</div>
</div>
<?php pradesh1_sm(-100,4,0,60);?>
<div class="col colspan4">
<div class="left_add">
<div class="okam-ad-position-wrap home-in-between-desh okam-device-desktop" data-alias="home-in-between-desh" data-device-type="desktop">
</div>
<div class="okam-ad-position-wrap home-in-between-desh-mb okam-device-mobile" data-alias="home-in-between-desh-mb" data-device-type="mobile">
</div>
</div>
</div>
<?php pradesh1_smside(-100,8,0,60);?>
</div>
</div>