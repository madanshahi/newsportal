<script type="text/javascript">
      window._wpemojiSettings = {"baseUrl":"https:\/\/s.w.org\/images\/core\/emoji\/13.0.1\/72x72\/","ext":".png","svgUrl":"https:\/\/s.w.org\/images\/core\/emoji\/13.0.1\/svg\/","svgExt":".svg","source":{"concatemoji":"https:\/\/<?php echo get_home_url();?>\/wp-includes\/js\/wp-emoji-release.min.js?ver=5.6.2"}};
      !function(e,a,t){var n,r,o,i=a.createElement("canvas"),p=i.getContext&&i.getContext("2d");function s(e,t){var a=String.fromCharCode;p.clearRect(0,0,i.width,i.height),p.fillText(a.apply(this,e),0,0);e=i.toDataURL();return p.clearRect(0,0,i.width,i.height),p.fillText(a.apply(this,t),0,0),e===i.toDataURL()}function c(e){var t=a.createElement("script");t.src=e,t.defer=t.type="text/javascript",a.getElementsByTagName("head")[0].appendChild(t)}for(o=Array("flag","emoji"),t.supports={everything:!0,everythingExceptFlag:!0},r=0;r<o.length;r++)t.supports[o[r]]=function(e){if(!p||!p.fillText)return!1;switch(p.textBaseline="top",p.font="600 32px Arial",e){case"flag":return s([127987,65039,8205,9895,65039],[127987,65039,8203,9895,65039])?!1:!s([55356,56826,55356,56819],[55356,56826,8203,55356,56819])&&!s([55356,57332,56128,56423,56128,56418,56128,56421,56128,56430,56128,56423,56128,56447],[55356,57332,8203,56128,56423,8203,56128,56418,8203,56128,56421,8203,56128,56430,8203,56128,56423,8203,56128,56447]);case"emoji":return!s([55357,56424,8205,55356,57212],[55357,56424,8203,55356,57212])}return!1}(o[r]),t.supports.everything=t.supports.everything&&t.supports[o[r]],"flag"!==o[r]&&(t.supports.everythingExceptFlag=t.supports.everythingExceptFlag&&t.supports[o[r]]);t.supports.everythingExceptFlag=t.supports.everythingExceptFlag&&!t.supports.flag,t.DOMReady=!1,t.readyCallback=function(){t.DOMReady=!0},t.supports.everything||(n=function(){t.readyCallback()},a.addEventListener?(a.addEventListener("DOMContentLoaded",n,!1),e.addEventListener("load",n,!1)):(e.attachEvent("onload",n),a.attachEvent("onreadystatechange",function(){"complete"===a.readyState&&t.readyCallback()})),(n=t.source||{}).concatemoji?c(n.concatemoji):n.wpemoji&&n.twemoji&&(c(n.twemoji),c(n.wpemoji)))}(window,document,window._wpemojiSettings);
    </script>
    <div id="fb-root"></div>
<script async defer crossorigin="anonymous" src="https://connect.facebook.net/en_US/sdk.js#xfbml=1&version=v10.0&appId=1352296205135078&autoLogAppEvents=1" nonce="Oz61F5sv"></script>
<style type="text/css">
img.wp-smiley,
img.emoji {
  display: inline !important;
  border: none !important;
  box-shadow: none !important;
  height: 1em !important;
  width: 1em !important;
  margin: 0 .07em !important;
  vertical-align: -0.1em !important;
  background: none !important;
  padding: 0 !important;
}
</style>
<link rel='stylesheet' id='wp-block-library-css' href='<?php bloginfo('template_url'); ?>/css/style.min.css?ver=5.6.2' type='text/css' media='all' />
<link rel='stylesheet' id='cld-font-awesome-css' href='<?php bloginfo('template_url'); ?>/css/font-awesome.min.css' type='text/css' media='all' />
<link rel='stylesheet' id='cld-frontend-css' href='<?php bloginfo('template_url'); ?>/css/cld-frontend.css' type='text/css' media='all' />
<link rel='stylesheet' id='okam-frontend-style-css' href='<?php bloginfo('template_url'); ?>/css/okam-frontend.css' type='text/css' media='all' />
<link rel='stylesheet' href='css/style.css' type='text/css' media='all' />
<link rel='stylesheet' id='ok18-main-style-css' href='<?php bloginfo('template_url'); ?>/css/okam-frontend.css' type='text/css' media='all' />
<link rel='stylesheet' id='ok18-calendar-style-css' href='<?php bloginfo('template_url'); ?>/css/nepali.datepicker.v2.2.min.css' type='text/css' media='all' />
<link rel='stylesheet' id='ok18-custom-css-css' href='<?php bloginfo('template_url'); ?>/css/ok-custom.css' type='text/css' media='all' />
<link rel='stylesheet' id='ok18-font-awesome-css' href='<?php bloginfo('template_url'); ?>/css/fontawesome-all.min.css' type='text/css' media='all' />
<script type='text/javascript' src='<?php bloginfo('template_url'); ?>/js/jquery.min.js' id='jquery-core-js'></script>
<script type='text/javascript' src='<?php bloginfo('template_url'); ?>/js/jquery-migrate.min.js' id='jquery-migrate-js'></script>
<script type='text/javascript' id='okc-frontend-script-js-extra'>
/* <![CDATA[ */
var okc_obj = {"ajax_url":"https:\/\/<?php echo get_home_url();?>\/wp-admin\/admin-ajax.php","ajax_nonce":"c5f81b4ca3"};
/* ]]> */
</script>
<script type='text/javascript' src='<?php bloginfo('template_url'); ?>/js/okc-frontend-script.js' id='okc-frontend-script-js'></script>
<script type='text/javascript' id='cld-frontend-js-extra'>
/* <![CDATA[ */
var cld_js_object = {"admin_ajax_url":"https:\/\/<?php echo get_home_url();?>\/wp-admin\/admin-ajax.php","admin_ajax_nonce":"04dfbbabff"};
/* ]]> */
</script>
<script type='text/javascript' src='<?php bloginfo('template_url'); ?>/js/cld-frontend.js' id='cld-frontend-js'></script>
<script type='text/javascript' src='<?php bloginfo('template_url'); ?>/js/canvasjs.min.js' id='okdv-canvas-js'></script>
<script type='text/javascript' src='<?php bloginfo('template_url'); ?>/js/okdv-frontend.js' id='okdv-script-js'></script>
<script type='text/javascript' src='<?php bloginfo('template_url'); ?>/js/underscore.min.js' id='underscore-js'></script>
<script src="https://kit.fontawesome.com/e5924ffe11.js" crossorigin="anonymous"></script>
<script type='text/javascript' id='wp-util-js-extra'>
/* <![CDATA[ */
var _wpUtilSettings = {"ajax":{"url":"\/wp-admin\/admin-ajax.php"}};
/* ]]> */
</script>
<script type='text/javascript' src='<?php bloginfo('template_url'); ?>/js/wp-util.min.js' id='wp-util-js'></script>
<script type='text/javascript' src='<?php bloginfo('template_url'); ?>/js/okam-mobile-detect.js' id='okam-mobile-detect-script-js'></script>
<script type='text/javascript' id='okam-frontend-script-js-extra'>
/* <![CDATA[ */
var okam_js_obj = {"ad_api_url":"https:\/\/<?php echo get_home_url();?>\/wp-json\/okapi\/v1","ajax_nonce":"5d2c846c15"};


<--!
/* ]]> */
</script>
<script type='text/javascript' src='<?php bloginfo('template_url'); ?>/js/okam-frontend.js' id='okam-frontend-script-js'></script>
<script type='text/javascript' src='<?php bloginfo('template_url'); ?>/js/addthis_widget.js' id='ok18-add-this-js'></script>
<script type='text/javascript' src='<?php bloginfo('template_url'); ?>/js/nepali.datepicker.v2.2.min.js' id='ok18-calendar-js-js'></script>
<script type='text/javascript' src='<?php bloginfo('template_url'); ?>/js/mobile-check.js' id='ok18-mobile-check-js-js'></script>
<script type='text/javascript' id='ok18-main-js-js-extra'> 
/* <![CDATA[ */
var ok18_frontend_script_obj = {"ajax_url":"https:\/\/<?php echo get_home_url();?>\/wp-admin\/admin-ajax.php","ajax_nonce":"6513f356e5","api_url":"https:\/\/<?php echo get_home_url();?>\/wp-json\/okapi\/v1\/"};
/* ]]> */
</script>
<script type='text/javascript' src='<?php bloginfo('template_url'); ?>/js/main.js' id='ok18-main-js-js'></script>
<link rel="https://api.w.org/" href="<?php echo get_home_url();?>/wp-json/" /><link rel="alternate" type="application/json" href="https://<?php bloginfo('template_url'); ?>/wp-json/wp/v2/pages/699430" /><link rel="EditURI" type="application/rsd+xml" title="RSD" href="https://<?php bloginfo('template_url'); ?>/xmlrpc.php?rsd" />
<link rel="wlwmanifest" type="application/wlwmanifest+xml" href="<?php echo get_home_url();?>/wp-includes/wlwmanifest.xml" />
<meta name="generator" content="WordPress 5.6.2" />
<link rel="canonical" href="<?php echo get_home_url();?>/" />
<link rel='shortlink' href='<?php echo get_home_url();?>/' />
<link rel="alternate" type="application/json+oembed" href="#" />
<link rel="alternate" type="text/xml+oembed" href="#" />
<script>
                window.fbAsyncInit = function () {
                    FB.init({
                        appId: '280041239029772',
                        xfbml: true,
                        version: 'v2.7'
                    });
                };

                (function (d, s, id) {
                    var js, fjs = d.getElementsByTagName(s)[0];
                    if (d.getElementById(id)) {
                        return;
                    }
                    js = d.createElement(s);
                    js.id = id;
                    js.src = "//connect.facebook.net/en_US/sdk.js";
                    fjs.parentNode.insertBefore(js, fjs);
                }(document, 'script', 'facebook-jssdk'));
            </script>
<script async src="https://www.googletagmanager.com/gtag/js?id=UA-4599822-2"></script>
<script>
    window.dataLayer = window.dataLayer || [];
    function gtag() {
        dataLayer.push(arguments);
    }
    gtag('js', new Date());

    gtag('config', 'UA-4599822-2');
</script>


<script type="text/javascript">
    _atrk_opts = {atrk_acct: "au/Vl1a8FRh2em", domain: "<?php echo get_home_url();?>", dynamic: true};
    (function () {
        var as = document.createElement('script');
        as.type = 'text/javascript';
        as.async = true;
        as.src = "https://certify-js.alexametrics.com/atrk.js";
        var s = document.getElementsByTagName('script')[0];
        s.parentNode.insertBefore(as, s);
    })();
</script>
<noscript><img src="#" style="display:none" height="1" width="1" alt="" /></noscript>
 <link rel="icon" href="#" sizes="32x32" />
<link rel="icon" href="#" />
<link rel="#" />
<meta name="msapplication-TileImage" content="#" />

<link href="<?php bloginfo('template_url'); ?>/css/owl.carousel.min.css" rel="stylesheet" />
<style>
            /*.site-header .ok__container*/
            /*{*/
                /*background:none!important;*/
            /*}*/
        </style>
        <meta property="fb:pages" content="108349739223556" />
<meta property="fb:app_id" content="366639890155270" />
<script type='text/javascript' src='https://platform-api.sharethis.com/js/sharethis.js#property=5f7d69b5342e510012c280bd&product=sop' async='async'></script>
<script src="https://d3c7xrz8693abq.cloudfront.net/widget.js?id=ONLINEKHABAR"></script>